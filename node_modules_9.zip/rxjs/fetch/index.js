"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var fetch_1 = require("../internal/observable/dom/fetch");
exports.fromFetch = fetch_1.fromFetch;
//# sourceMappingURL=index.js.map