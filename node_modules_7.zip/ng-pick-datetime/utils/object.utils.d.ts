export declare function extendObject(dest: any, ...sources: any[]): any;
