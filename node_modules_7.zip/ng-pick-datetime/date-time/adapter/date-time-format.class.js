import { InjectionToken } from '@angular/core';
export var OWL_DATE_TIME_FORMATS = new InjectionToken('OWL_DATE_TIME_FORMATS');
