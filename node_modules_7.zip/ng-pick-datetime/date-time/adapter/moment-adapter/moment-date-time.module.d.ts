export declare class MomentDateTimeModule {
}
export declare class OwlMomentDateTimeModule {
}
