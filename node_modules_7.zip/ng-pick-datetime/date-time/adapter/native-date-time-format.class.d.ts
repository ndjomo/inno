import { OwlDateTimeFormats } from './date-time-format.class';
export declare const OWL_NATIVE_DATE_TIME_FORMATS: OwlDateTimeFormats;
