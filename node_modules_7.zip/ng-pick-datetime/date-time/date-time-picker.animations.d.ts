import { AnimationTriggerMetadata } from '@angular/animations';
export declare const owlDateTimePickerAnimations: {
    readonly transformPicker: AnimationTriggerMetadata;
    readonly fadeInPicker: AnimationTriggerMetadata;
};
