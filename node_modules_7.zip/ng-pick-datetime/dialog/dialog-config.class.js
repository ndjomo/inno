import { NoopScrollStrategy } from '@angular/cdk/overlay';
var uniqueId = 0;
var OwlDialogConfig = (function () {
    function OwlDialogConfig() {
        this.ariaDescribedBy = null;
        this.autoFocus = true;
        this.hasBackdrop = true;
        this.data = null;
        this.disableClose = false;
        this.role = 'dialog';
        this.paneClass = '';
        this.event = null;
        this.backdropClass = '';
        this.closeOnNavigation = true;
        this.width = '';
        this.height = '';
        this.maxWidth = '85vw';
        this.scrollStrategy = new NoopScrollStrategy();
        this.id = "owl-dialog-" + uniqueId++;
    }
    return OwlDialogConfig;
}());
export { OwlDialogConfig };
