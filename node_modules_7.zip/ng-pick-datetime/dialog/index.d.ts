export { OwlDialogModule } from './dialog.module';
export { OwlDialogService } from './dialog.service';
export { OwlDialogRef } from './dialog-ref.class';
