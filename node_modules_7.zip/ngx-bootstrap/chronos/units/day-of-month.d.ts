export declare function initDayOfMonth(): void;
