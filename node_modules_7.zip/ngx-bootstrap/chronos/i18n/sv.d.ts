import { LocaleData } from '../locale/locale.class';
export declare const svLocale: LocaleData;
