export declare function cloneDate(date: Date): Date;
