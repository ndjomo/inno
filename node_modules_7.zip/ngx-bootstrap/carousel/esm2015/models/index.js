/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * @record
 */
export function SlideWithIndex() { }
if (false) {
    /** @type {?} */
    SlideWithIndex.prototype.item;
    /** @type {?} */
    SlideWithIndex.prototype.index;
}
/**
 * @record
 */
export function IndexedSlideList() { }
if (false) {
    /** @type {?} */
    IndexedSlideList.prototype.list;
    /** @type {?} */
    IndexedSlideList.prototype.index;
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290Ijoibmc6Ly9uZ3gtYm9vdHN0cmFwL2Nhcm91c2VsLyIsInNvdXJjZXMiOlsibW9kZWxzL2luZGV4LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7QUFFQSxvQ0FHQzs7O0lBRkMsOEJBQXFCOztJQUNyQiwrQkFBYzs7Ozs7QUFHaEIsc0NBR0M7OztJQUZDLGdDQUF1Qjs7SUFDdkIsaUNBQWMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBTbGlkZUNvbXBvbmVudCB9IGZyb20gJy4uL3NsaWRlLmNvbXBvbmVudCc7XG5cbmV4cG9ydCBpbnRlcmZhY2UgU2xpZGVXaXRoSW5kZXgge1xuICBpdGVtOiBTbGlkZUNvbXBvbmVudDtcbiAgaW5kZXg6IG51bWJlcjtcbn1cblxuZXhwb3J0IGludGVyZmFjZSBJbmRleGVkU2xpZGVMaXN0IHtcbiAgbGlzdDogU2xpZGVXaXRoSW5kZXhbXTtcbiAgaW5kZXg6IG51bWJlcjtcbn1cbiJdfQ==