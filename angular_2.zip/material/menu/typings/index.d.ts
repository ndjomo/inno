/**
 * Generated bundle index. Do not edit.
 */
export * from './public-api';
export { MAT_MENU_DEFAULT_OPTIONS_FACTORY as ɵa24 } from './menu-directive';
export { MatMenuItemBase as ɵb24, _MatMenuItemMixinBase as ɵc24 } from './menu-item';
export { MAT_MENU_PANEL as ɵf24 } from './menu-panel';
export { MAT_MENU_SCROLL_STRATEGY_FACTORY as ɵd24, MAT_MENU_SCROLL_STRATEGY_FACTORY_PROVIDER as ɵe24 } from './menu-trigger';
