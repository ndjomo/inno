import CustomTooltips from './custom-tooltips'
const customTooltips = CustomTooltips
// TODO: camel-case
export {
  CustomTooltips,
  customTooltips
}
