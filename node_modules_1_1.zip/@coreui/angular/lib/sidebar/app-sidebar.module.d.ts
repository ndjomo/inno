export declare class AppSidebarModule {
}
