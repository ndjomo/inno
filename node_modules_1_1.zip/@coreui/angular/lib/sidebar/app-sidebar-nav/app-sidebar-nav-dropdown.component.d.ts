import { SidebarNavHelper } from '../app-sidebar-nav.service';
export declare class AppSidebarNavDropdownComponent {
    helper: SidebarNavHelper;
    item: any;
    constructor(helper: SidebarNavHelper);
}
