import { OnInit } from '@angular/core';
export declare class AppSidebarNavDividerComponent implements OnInit {
    item: any;
    constructor();
    ngOnInit(): void;
}
