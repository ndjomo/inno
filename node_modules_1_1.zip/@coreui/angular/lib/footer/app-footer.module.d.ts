export declare class AppFooterModule {
}
