export declare class AppAsideModule {
}
