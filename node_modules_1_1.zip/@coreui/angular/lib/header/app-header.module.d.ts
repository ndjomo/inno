export declare class AppHeaderModule {
}
