import { ModuleWithProviders } from '@angular/core';
export declare class AppBreadcrumbModule {
    static forRoot(config?: any): ModuleWithProviders;
}
