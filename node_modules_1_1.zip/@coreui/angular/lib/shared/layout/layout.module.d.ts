export declare class LayoutModule {
}
