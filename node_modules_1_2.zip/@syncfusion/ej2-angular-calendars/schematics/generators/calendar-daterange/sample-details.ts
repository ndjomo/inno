export const componentName: string = 'calendar';
export const sampleName: string = 'daterange';
export const diModules: string =  null;
export const packageName: string = '@syncfusion/ej2-angular-calendars';
export const libModules: string = 'CalendarModule';
