export declare const componentName: string;
export declare const sampleName: string;
export declare const diModules: string;
export declare const packageName: string;
export declare const libModules: string;
