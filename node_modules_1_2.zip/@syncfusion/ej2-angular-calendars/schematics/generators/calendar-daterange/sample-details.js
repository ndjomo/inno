"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.componentName = 'calendar';
exports.sampleName = 'daterange';
exports.diModules = null;
exports.packageName = '@syncfusion/ej2-angular-calendars';
exports.libModules = 'CalendarModule';
