"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.componentName = 'datetimepicker';
exports.sampleName = 'format';
exports.diModules = null;
exports.packageName = '@syncfusion/ej2-angular-calendars';
exports.libModules = 'DateTimePickerModule';
