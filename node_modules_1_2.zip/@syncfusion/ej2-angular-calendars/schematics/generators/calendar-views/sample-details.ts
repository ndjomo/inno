export const componentName: string = 'calendar';
export const sampleName: string = 'views';
export const diModules: string =  null;
export const packageName: string = '@syncfusion/ej2-angular-calendars';
export const libModules: string = 'CalendarModule';
