"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.componentName = 'daterangepicker';
exports.sampleName = 'disableddates';
exports.diModules = null;
exports.packageName = '@syncfusion/ej2-angular-calendars';
exports.libModules = 'DateRangePickerModule';
