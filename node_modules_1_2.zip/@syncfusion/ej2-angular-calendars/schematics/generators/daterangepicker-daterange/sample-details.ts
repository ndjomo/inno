export const componentName: string = 'daterangepicker';
export const sampleName: string = 'daterange';
export const diModules: string =  null;
export const packageName: string = '@syncfusion/ej2-angular-calendars';
export const libModules: string = 'DateRangePickerModule';
