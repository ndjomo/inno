export const componentName: string = 'datepicker';
export const sampleName: string = 'multiselection';
export const diModules: string =  null;
export const packageName: string = '@syncfusion/ej2-angular-calendars';
export const libModules: string = 'DatePickerModule';
