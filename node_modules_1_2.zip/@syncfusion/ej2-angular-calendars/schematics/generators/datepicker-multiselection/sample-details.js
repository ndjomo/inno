"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.componentName = 'datepicker';
exports.sampleName = 'multiselection';
exports.diModules = null;
exports.packageName = '@syncfusion/ej2-angular-calendars';
exports.libModules = 'DatePickerModule';
