export const componentName: string = 'daterangepicker';
export const sampleName: string = 'format';
export const diModules: string =  null;
export const packageName: string = '@syncfusion/ej2-angular-calendars';
export const libModules: string = 'DateRangePickerModule';
