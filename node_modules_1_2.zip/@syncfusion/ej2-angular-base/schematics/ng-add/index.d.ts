import { Rule } from '@angular-devkit/schematics';
import { LibOptionsSchema, OptionsSchema } from './schema';
export declare function install(options: OptionsSchema, libOptions: LibOptionsSchema): Rule;
