export declare function emitSampleFiles(pkgName: string): void;
