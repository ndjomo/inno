import { Rule } from '@angular-devkit/schematics';
import { Schema as PipeOptions } from './schema';
export default function (options: PipeOptions): Rule;
