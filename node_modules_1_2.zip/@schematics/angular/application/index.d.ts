import { Rule } from '@angular-devkit/schematics';
import { Schema as ApplicationOptions } from './schema';
export default function (options: ApplicationOptions): Rule;
