The 'eject' command has been disabled and will be removed completely in 8.0.
The new configuration format provides increased flexibility to modify the
configuration of your workspace without ejecting.

There are several projects that can be used in conjuction with the new
configuration format that provide the benefits of ejecting without the maintenance
overhead.  One such project is ngx-build-plus found here:
https://github.com/manfredsteyer/ngx-build-plus