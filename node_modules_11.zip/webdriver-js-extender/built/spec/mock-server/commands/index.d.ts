import { SessionCommandList } from '../interfaces';
export declare let session: SessionCommandList;
