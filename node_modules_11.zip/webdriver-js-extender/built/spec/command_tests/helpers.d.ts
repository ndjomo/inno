import { ExtendedWebDriver } from '../../lib';
export declare function initMockSeleniumStandaloneServerAndGetDriverFactory(annotateCommands?: boolean): () => ExtendedWebDriver;
