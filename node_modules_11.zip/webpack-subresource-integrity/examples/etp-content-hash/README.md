# ExtractTextPlugin and `contenthash` #etp

Test case for issue #22
