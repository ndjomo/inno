# HtmlWebpackPlugin and Sub-Directories #hwp

Test case for issue #9

