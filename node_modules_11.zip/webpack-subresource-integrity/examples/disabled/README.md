# Plugin Disabled

Simple example showing that webpack-subresource-integrity doesn't add
an integrity checksum when `enabled` is set to `false`.
