# HtmlWebpackPlugin and publicPath #hwp

Test case for issue #11
