# ExtractTextPlugin and Sub-Directory with `path.join` #etp

Test case for issue #22
