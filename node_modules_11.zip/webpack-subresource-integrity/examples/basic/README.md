# With HtmlWebpackPlugin #hwp

This is a most basic test for use with HtmlWebpackPlugin
