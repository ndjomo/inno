# Circular Dependencies

Test case for issue #7
