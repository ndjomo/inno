# Issue 83

Test case for issue #83
