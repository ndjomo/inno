
# throttle

  Throttle a function

## Installation

    $ component install component/throttle

## API

   

## License

  MIT
