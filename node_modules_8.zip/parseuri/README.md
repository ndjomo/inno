# parseuri
Module for parsing URI's in engine.io-client
